<div class="container-fluid">
	<h2 class="text-warning" style="font-weight: bold;">Monthly Efficiency Chart</h2>
	<p class="lead" style="margin-top: -15px;"><div class="text-warning realclock" style="font-weight: bold;"></div></p>
	<p>
		<input type="text" class="input-sm text-center" id="yearpicker" name="active_year" value="<?=$tgl_obj->format('Y');?>" style="width:100px; font-weight: bold; height: 40px;" readonly>
	</p>
	<div id="monthly" ></div>
</div>