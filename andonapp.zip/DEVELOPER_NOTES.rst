###################
Andon APP v.1.0.0
###################

DEVELOPER NOTES
================

- Untuk merubah interval dari slide silahkan rubah nilai constant pada **application/config/constants.php** lalu ubah nilai variable **ZINTERVAL**

- Untuk account yang tersedia (DEFAULT):

=========  ==========
Username	PASSWORD
=========  ==========
office		office
m1 			m1
m2 			m2
m3 			m3
=========  ==========