###################
Andon APP v.1.0.0
2020-07-13
Created By:
- RezzaAnwary
- AdamPrasetyaMalik

Special Thanks to: Daichi
###################

Andon APP, dibuat untuk support untuk menampilkan data efficiency dari mesin Andon.

**************************
Changelog and New Features
**************************

V.1.0.0
========
Release Date: 2020-07-15

First release version.

V.1.0.1
========
Release Date: Not Released

Not Released.

*******************
Server Requirements
*******************

- PHP (7.3^)
- MySql Database (5.1^)
- Codeigniter Framework (3.1.10)
- jQuery (3.5.1^)
- Node-Red

************
Installation
************

For Installation Detail Contact:
Rezza Anwary 		: +62 823-2940-9419
Adam Prasetya Malik : +62 8211-4579-976
